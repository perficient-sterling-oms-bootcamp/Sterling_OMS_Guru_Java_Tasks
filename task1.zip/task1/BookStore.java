package com.sterling.task;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author guru.santhosh
 *
 */
public class BookStore {
	static ArrayList<Books> booksList = new ArrayList<Books>();
	static Scanner obj = new Scanner(System.in);

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int unit;
		System.out.println("Enter the amount of books need to add");
		unit = obj.nextInt();
		booksEntry(unit);
		new BookXmlCreation(booksList, unit);
	}

	/**
	 * @param unit
	 */
	private static void booksEntry(int unit) {
		for (int i = 0; i < unit; i++) {
			Books books = new Books();
			System.out.println("Enter the book name");
			books.setName(obj.next());
			System.out.println("Enter the author name");
			books.setAuthor(obj.next());
			System.out.println("Enter the isbn number");
			books.setIsbn(obj.next());
			System.out.println("Enter the publisher name");
			books.setPublisher(obj.next());
			validation(books);
			booksList.add(books);

			// System.out.println("enter the book price");
			/*
			 * try { books.setPrice(obj.nextFloat());
			 * 
			 * } catch (Exception e) { System.out.
			 * println("Book Price can only be in decimal/integer digits");
			 * System.out.println("Please enter the correct number");
			 * 
			 * 
			 * }
			 */
		}

	}

	public static void validation(Books books) {
		boolean success = false;
		int count = 0;
		while (!success) {
			try {
				if (count < 3) {
					System.out.print("Enter an book price: ");
					books.setPrice(obj.nextFloat());
					success = true;
				} else {
					System.out.println("Sorry!..You have Exceed the maximum tries.. ");
					System.exit(0);
				}

			} catch (InputMismatchException e) {
				obj.next();
				System.out.println("Book Price can only be in decimal/integer digits");
				count++;
			}
		}

	}

}
