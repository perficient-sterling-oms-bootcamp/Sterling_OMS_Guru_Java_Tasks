package com.sterling.task;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

public class BookXmlCreation {
	
	public BookXmlCreation(ArrayList<Books> booksList, int unit) {

		try{
			 DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();  
		     DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			 Document document = documentBuilder.newDocument();
			  Element rootElement = document.createElement("BookList");
			  document.appendChild(rootElement);
			  for(int i=0;i<unit;i++)
			  {
				 
			  Element book= document.createElement("Book");
			  rootElement.appendChild(book);
			  
			  Element bookname=document.createElement("Name");
			  bookname.appendChild(document.createTextNode(booksList.get(i).getName()));
			  book.appendChild(bookname);
			  
			  Element bookprice = document.createElement("Price");
			  bookprice.appendChild(document.createTextNode(String.valueOf(booksList.get(i).getPrice())));
			  book.appendChild(bookprice);
			  
			  Element authorname = document.createElement("Author");
			  authorname.appendChild(document.createTextNode(booksList.get(i).getAuthor()));
			  book.appendChild(authorname);
			  
			  Element info = document.createElement("Information");
			 
			  
			  Element isbn = document.createElement("Isbn");
			  isbn.appendChild(document.createTextNode(booksList.get(i).getIsbn()));
			  info.appendChild(isbn);
			  
			  Element pub = document.createElement("Publisher");
			  pub.appendChild(document.createTextNode(booksList.get(i).getPublisher()));
			  info.appendChild(pub);
			  
			  book.appendChild(info);
			  
			  
			  
			  }
			  TransformerFactory transformerfactory = TransformerFactory.newInstance();
			  Transformer transformer = transformerfactory.newTransformer();
			  
			  transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			  transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				DOMSource domSource = new DOMSource(document);
			  StreamResult streamResult = new StreamResult(new File("C:/New folder/task1.xml"));  
					  
					   transformer.transform(domSource, streamResult);  	
					   System.out.println("Books details has been sucessfully created");
		}
			
		 catch (ParserConfigurationException e) {
			
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			
			e.printStackTrace();
		} catch (TransformerException e) {
			
			e.printStackTrace();
		}
	
	}
}
