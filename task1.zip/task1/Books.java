package com.sterling.task;

public class Books {
	
	private String name;
	private float price;
	private String author;
	private String isbn;
	private String publisher;
	
 	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getName() {
		return name;
	}

	public float getPrice() {
		return price;
	}

	public String getAuthor() {
		return author;
	}
	
	
	/*public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
*/	// @Override
	// public String toString() {
	// return "Books [name=" + name + ", price=" + price + ", author=" + author
	// + "]";
	// }

}
