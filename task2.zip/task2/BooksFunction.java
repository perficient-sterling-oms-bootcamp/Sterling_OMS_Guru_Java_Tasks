package com.task;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class BooksFunction {
	static Scanner obj = new Scanner(System.in);
	static String name;
	static String author;
	static Float price;
	static int unit = 0;
	static List<Books> booklist = new ArrayList<Books>();
	BookStore bs = new BookStore();

	public Element createBook(String name, Float price, String author) {

		Books books = new Books();
		Element rootElement = null;
		books.setName(name);
		books.setAuthor(author);
		books.setPrice(price);
		booklist.add(books);

		int length = booklist.size();
		if (length == bs.unit) {
			try {
				DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();
				rootElement = document.createElement("BookList");
				document.appendChild(rootElement);
				for (int i = 0; i < length; i++) {
					Element book = document.createElement("Book");
					rootElement.appendChild(book);

					Element bookname = document.createElement("Name");
					bookname.appendChild(document.createTextNode(booklist.get(i).getName()));
					book.appendChild(bookname);

					Element bookprice = document.createElement("Price");
					bookprice.appendChild(document.createTextNode(String.valueOf(booklist.get(i).getPrice())));
					book.appendChild(bookprice);

					Element authorname = document.createElement("Author");
					authorname.appendChild(document.createTextNode(booklist.get(i).getAuthor()));
					book.appendChild(authorname);

				}
				xmlCreation(document, rootElement);
				System.out.println("Books details has been sucessfully created");

			} catch (ParserConfigurationException e) {

				e.printStackTrace();
			}

		}
		return null;

	}

	public Document addBook(Document document, Element bookElement) {

		ArrayList<Books> booksList = new ArrayList<Books>();
		int unit = 0;
		System.out.println("How many unit of books need to be add");
		unit = obj.nextInt();
		for (int i = 0; i < unit; i++) {
			Books books = new Books();
			System.out.println("Enter the book name");
			books.setName(obj.next());
			System.out.println("Enter the author name");
			books.setAuthor(obj.next());
			BookStore.validation(books);
			booksList.add(books);
		}

		for (int i = 0; i < unit; i++) {

			Element book = document.createElement("Book");
			bookElement.appendChild(book);

			Element bookname = document.createElement("Name");
			bookname.appendChild(document.createTextNode(booksList.get(i).getName()));
			book.appendChild(bookname);

			Element bookprice = document.createElement("Price");
			bookprice.appendChild(document.createTextNode(String.valueOf(booksList.get(i).getPrice())));
			book.appendChild(bookprice);

			Element authorname = document.createElement("Author");
			authorname.appendChild(document.createTextNode(booksList.get(i).getAuthor()));
			book.appendChild(authorname);
		}
		xmlCreation(document, bookElement);
		System.out.println("Books details has been sucessfully added");
		return null;

	}

	public Document deleteBook(Document document, Element bookElement) {
		String bookdelete;
		System.out.println("Enter the Book name you want to delete:");
		bookdelete = obj.next();
		NodeList node = document.getElementsByTagName("Book");
		for (int i = 0; i < node.getLength(); i++) {
			Element book = (Element) node.item(i);
			Element name = (Element) book.getElementsByTagName("Name").item(0);
			String bookname = name.getTextContent();
			if (bookname.equals(bookdelete)) {
				book.getParentNode().removeChild(book);
			}
		}

		xmlCreation(document, bookElement);
		System.out.println("Books details has been sucessfully deleted");
		return null;

	}

	public Document updateBook(String updatedBookName, Float price, String author) {
		String filepath = "C:/New folder/task2.xml";

		DocumentBuilderFactory documentfactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentbuiler;
		try {
			documentbuiler = documentfactory.newDocumentBuilder();
			Document document = documentbuiler.parse(filepath);
			Node rootelement = document.getFirstChild();
			Element bookElement = (Element) rootelement;
			NodeList node = document.getElementsByTagName("Book");
			for (int i = 0; i < node.getLength(); i++) {
				Element book = (Element) node.item(i);
				Element name = (Element) book.getElementsByTagName("Name").item(0);
				String bookname = name.getTextContent();

				if (bookname.equals(updatedBookName)) {
					Element bookprice = (Element) book.getElementsByTagName("Price").item(0);
					String updatedprice = bookprice.getTextContent();
					if (updatedprice != String.valueOf(price)) {
						bookprice.setTextContent(String.valueOf(price));
					} else {
						System.out.println("Price are already same");
					}

				}
			}
			xmlCreation(document, bookElement);
			System.out.println("Books details has been sucessfully updated");
		}

		catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;

	}

	public Element findBook(String searchName) {

		String filepath = "C:/New folder/task2.xml";
		DocumentBuilderFactory documentfactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentbuiler;
		try {
			documentbuiler = documentfactory.newDocumentBuilder();
			Document document = documentbuiler.parse(filepath);
			Node rootelement = document.getFirstChild();
			Element bookElement = (Element) rootelement;
			NodeList node = document.getElementsByTagName("Book");
			for (int i = 0; i < node.getLength(); i++) {
				Element book = (Element) node.item(i);
				Element name = (Element) book.getElementsByTagName("Name").item(0);
				String bookname = name.getTextContent();
				System.out.println(searchName + bookname);
				if (searchName.equals(bookname)) {

					System.out.println("insdie search");
					Element price = (Element) book.getElementsByTagName("Price").item(0);
					String bookprice = price.getTextContent();
					Element author = (Element) book.getElementsByTagName("Author").item(0);
					String bookAuthor = author.getTextContent();
					System.out.println("Book details");
					System.out.println("Book name-" + bookname);
					System.out.println("Book price-" + bookprice);
					System.out.println("Book author-" + bookAuthor);
					break;
				} else if (searchName != bookname) {
					continue;
				} else {
					System.out.println("Sorry!.. Book is not present");
					break;
				}
			}

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;

	}

	public void xmlCreation(Document document, Element rootElement) {
		TransformerFactory transformerfact = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = transformerfact.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File("C:/New folder/task2.xml"));
			transformer.transform(domSource, streamResult);

		} catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}

	}

}
