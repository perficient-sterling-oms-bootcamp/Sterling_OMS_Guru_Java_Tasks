package com.task;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;



public class BookStore {
	static Scanner sc = new Scanner(System.in);
	static BooksFunction bookfun = new BooksFunction();
	static String name;
	static String author;
	static Float price;
	static int unit = 0;

	public static void main(String[] args) {

		userMenu();

	}

	public static void userMenu() {
		int choice = 0;
		System.out.println("* For Creating a book - press 1");
		System.out.println("* For Adding a book - press 2");
		System.out.println("* For deleting a book - Press 3");
		System.out.println("* For Changing the existing book details - Press 4");
		System.out.println("* For searching book - press 5");
		System.out.println("* Exit - Press anything else");
		System.out.println("Enter your choice");
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			creatingBook();
			userMenu();
			break;
		case 2:
			addingBook();
			userMenu();
			break;
		case 3:
			deleteBook();
			userMenu();
			break;
		case 4:
			changeBookDetails();
			userMenu();
			break;
		case 5:
			searchingBook();
			
			break;
		default:
			System.out.println("Sorry!.. You have entered incorrect choice");
			break;

		}
	}

	

	private static void creatingBook() {

		System.out.println("How many unit of books need to be add:");
		unit = sc.nextInt();

		for (int i = 0; i < unit; i++) {
			Books books = new Books();
			System.out.println("Enter the book name:");
			books.setName(sc.next());
			System.out.println("Enter the author name:");
			books.setAuthor(sc.next());
			validation(books);
			bookfun.createBook(books.getName(), books.getPrice(), books.getAuthor());
		}

	}

	public static void addingBook() {

		try {
			String filepath = "C:/New folder/task2.xml";
			DocumentBuilderFactory documentfactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentbuiler = documentfactory.newDocumentBuilder();
			Document document = documentbuiler.parse(filepath);
			Node rootelement = document.getFirstChild();
			Element bookElement = (Element) rootelement;
			bookfun.addBook(document, bookElement);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private static void deleteBook() {
		try {
			String filepath = "C:/New folder/task2.xml";
			DocumentBuilderFactory documentfactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentbuiler = documentfactory.newDocumentBuilder();
			Document document = documentbuiler.parse(filepath);
			Node rootelement = document.getFirstChild();
			Element bookElement = (Element) rootelement;
			bookfun.deleteBook(document, bookElement);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private static void changeBookDetails() {
		System.out.println("Enter the Book name:");
		name = sc.next();
		System.out.println("Enter the author name");
		author = sc.next();
		System.out.println("Enter the Book price");
		price = sc.nextFloat();
		bookfun.updateBook(name, price, author);

	}
	private static void searchingBook() {
	       System.out.println("Please enter the book which u need to search");
	       String searchBook= sc.nextLine();
	       bookfun.findBook(searchBook);
	       
		
	}
	public static void validation(Books books) {
		boolean success = false;
		int count = 0;
		while (!success) {
			try {
				if (count < 3) {
					System.out.print("Enter an book price: ");
					books.setPrice(sc.nextFloat());
					success = true;
				} else {
					System.out.println("Sorry!..You have Exceed the maximum tries.. ");
					System.exit(0);
				}

			} catch (InputMismatchException e) {
				sc.next();
				System.out.println("Book Price can only be in decimal/integer digits");
				count++;
			}
		}

	}

}
